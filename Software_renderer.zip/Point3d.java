//Mateusz Pawlowski. 3D Software Renderer. 2023.

package pkg3d;

import java.math.BigDecimal;

/**
 *
 * @author M
 */
public class Point3d {

Float x;
Float y;
Float z;



Float xr;
Float yr;
Float zr;

Float xr2;
Float yr2;
Float zr2;

Integer x2d;
Integer y2d;




Point3d(float x,float y)
{
this.x=x;
this.y=y;
this.z=z;
}
Point3d(float x,float y,float z)
{
this.x=x;
this.y=y;
this.z=z;
}

Point3d get2dPoint()
{
    float d=400;
    float x2=0;
    float y2=0;
                
                
                
                if (zr2 + d != 0) {
		
                        if (zr2 + d > 0)
                        {
                                x2 = 256 + (xr2 * d) / (zr2 + d);
                                y2 = 256 + (yr2 * d) / (zr2 + d);
                        }

			if (zr2 + d < 0)
			{
				x2 = 256 + (xr2 * d) / (-598 + (d));
				y2 = 256 + (yr2 * d) / (-598 + (d));
			}
		
                }
                else {
		    if (zr2 + d <= 0)
                    {
                            x2 = 256 + (xr2 * d) / (-598 + (d));
                            y2 = 256 + (yr2 * d) / (-598 + (d));
                    }
                }
                
    
    
    return new Point3d((float)x2,(float)y2);
}


public void moveVectorOriginal(float a,float b,float c)
{

x=x+a;
y=y+b;
z=z+c;
}


public void moveVector(float a,float b,float c)
{

xr2=xr2+a;
yr2=yr2+b;
zr2=zr2+c;
}

public void calculate2dpoint()
{
Point3d point=this.get2dPoint();
this.x2d=(int)(point.x*1);
this.y2d=(int)(point.y*1);
}

public void rotateAxisY(double alpha)
{
        alpha = alpha * 3.14 / 180;
        
	float tx = (float)(Math.cos(alpha)*x + Math.sin(alpha)*z);
	float tz = (float)(-Math.sin(alpha)*x + Math.cos(alpha)*z);
        
        
        this.yr=y;
        this.xr=tx;
        this.zr=tz;
}

public void rotateAxisX(double alpha)
{
        alpha = alpha * 3.14 / 180;
        
	float ty = (float)(Math.cos(alpha)*yr - Math.sin(alpha)*zr);
	float tz = (float)(Math.sin(alpha)*yr + Math.cos(alpha)*zr);
        
        this.yr2=ty;
        this.zr2=tz;
        
        this.xr2=xr;
}

 
}
