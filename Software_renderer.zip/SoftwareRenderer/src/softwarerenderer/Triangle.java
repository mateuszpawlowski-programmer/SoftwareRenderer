//Mateusz Pawlowski. 3D Software Renderer. 2023.

package softwarerenderer;

import java.util.ArrayList;


/**
 *
 * @author M
 */
public class Triangle implements Comparable{

Point3d v1=null;
Point3d v2=null;
Point3d v3=null;
Point3d v4=null;

Float z;




public Triangle(Point3d v1,Point3d v2,Point3d v3)
{
this.v1=v1;
this.v2=v2;
this.v3=v3;

z=v1.zr2;
}

public Triangle(Point3d v1,Point3d v2,Point3d v3,Point3d v4)
{
this.v1=v1;
this.v2=v2;
this.v3=v3;
this.v4=v4;
//this.v4.calculate2dpoint();

z=v1.zr2;
}

    @Override
    public int compareTo(Object o) {
        int wynik=-1;
        if (((Triangle)o).z>this.z) wynik=1;
        
        //System.out.println(((Triangle)o).z);
        //System.out.println(this.z);
        
        return wynik;
    }
}
