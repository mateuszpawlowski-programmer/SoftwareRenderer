//Mateusz Pawlowski. 3D Software Renderer. 2023.

package pkg3d;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.StringTokenizer;
import javax.swing.*;

 
public class R_3D extends JPanel implements Runnable {

    /**
     * @param args the command line arguments
     */
        public JPanel panel;
        
        public JFrame frame = new JFrame("Mateusz Pawlowski. 3D Software Renderer.");
        
        ArrayList<Point3d> vertices=new ArrayList<Point3d>();
        
        //ArrayList<Point3d> normals=new ArrayList<Point3d>();
        //ArrayList<Integer> normals_index=new ArrayList<Integer>();
        
        ArrayList<Integer> faces=new ArrayList<Integer>();
                
        JButton b1=new JButton("<");
        JButton b2=new JButton(">");
        JButton b5=new JButton("Play");
        JButton b3=new JButton("^");
        JButton b4=new JButton("v");
        
        JButton b6=new JButton("+");
        JButton b7=new JButton("-");
        
        JButton b8=new JButton("WireFrame");
        JButton b9=new JButton("S");
        
        JButton b10=new JButton("1");
        JButton b11=new JButton("2");
        JButton b12=new JButton("3");
        
        boolean application_running=true;
        
        double cube_angleX=0;
        double cube_angleY=0;
        
        boolean play=false;
        
        int scale=0;
        
        static boolean draw_demo=false;
        static boolean tomb_raider=false;
        static boolean lamborghini=true;
        static boolean crash_bandicoot=false;
        
        static boolean wire_frame=false;
        
        int sc=3;
        
        Point3d p1=new Point3d(-10*sc,-10*sc,-10*sc);
        Point3d p2=new Point3d(10*sc,-10*sc,-10*sc);
        Point3d p3=new Point3d(-10*sc,10*sc,-10*sc);
        Point3d p4=new Point3d(10*sc,10*sc,-10*sc);
        
        Point3d p5=new Point3d(-10*sc,-10*sc,10*sc);
        Point3d p6=new Point3d(10*sc,-10*sc,10*sc);
        Point3d p7=new Point3d(-10*sc,10*sc,10*sc);
        Point3d p8=new Point3d(10*sc,10*sc,10*sc);
        
        Point3d[] tab=new Point3d[]{p1,p2,p3,p4,p5,p6,p7,p8};
        
        Point3d pn1=new Point3d(0,0,-10);
        Point3d pn2=new Point3d(0,0,10);
        
        Point3d pn3=new Point3d(0,-10,0);
        Point3d pn4=new Point3d(0,10,0);
        
        Point3d pn5=new Point3d(10,0,0);
        Point3d pn6=new Point3d(-10,0,0);
        
        double angle=0;
        Graphics g;
        
        public Thread thread;
        
        
        
        
    
    public R_3D()
    {
                
                //read .obj file with 3d object
                int count_normals=0;
                
                try{
                BufferedReader bfr=null;
                if(lamborghini==true){bfr=new BufferedReader(new FileReader("lamborghini.obj"));}
                
                if(tomb_raider==true){bfr=new BufferedReader(new FileReader("tomb_raider.obj"));}
                
                if(crash_bandicoot==true){bfr=new BufferedReader(new FileReader("crash_bandicoot.obj"));}
                
                int count_vertices=0;
                
                int count_faces=0;
                
                String linia=bfr.readLine();
                
                while(linia!=null)
                {
                
                
                StringTokenizer st=new StringTokenizer(linia);
                String litera=st.nextToken(" ");
                
                        if(litera.equals("v")){

                        Float vx=Float.parseFloat(st.nextToken(" "));
                        Float vy=Float.parseFloat(st.nextToken(" "));
                        Float vz=Float.parseFloat(st.nextToken(" "));
                        
                        //System.out.println(" "+vx+" "+vy+" "+vz);
                        
                        if(tomb_raider==true)
                        {
                        vertices.add(new Point3d(vx*10,-vy*10,-vz*10));
                        }
                        
                        if(lamborghini==true)
                        {
                        vertices.add(new Point3d(vx*40,-vy*40,-vz*40));
                        }
                        
                        if(crash_bandicoot==true)
                        {
                        vertices.add(new Point3d(vx*10,-vy*10,-vz*10));
                        }
                        
                        count_vertices++;
                        
                        }
                        
                        //osobny fragment dla lamborghini
                         
                         //System.out.println(linia);
                         if(lamborghini==true)
                         {
                                if(litera.equals("f"))
                                {
                                //System.out.println(linia);
                                
                                String t1=st.nextToken(" ");
                                String t2=st.nextToken(" ");
                                String t3=st.nextToken(" ");
                                
                                String t4=null;
                                try{
                                    t4=st.nextToken(" ");
                                }catch(Exception exc){}



                                StringTokenizer st_1=new StringTokenizer(t1);
                                String l=st_1.nextToken("//");
                                
                                StringTokenizer st_2=new StringTokenizer(t2);
                                String ll=st_2.nextToken("//");
                                
                                StringTokenizer st_3=new StringTokenizer(t3);
                                String lll=st_3.nextToken("//");
                                
                                //System.out.println(""+t4);
                                
                                if(t4==null)
                                {
                                //System.out.println(" "+l+" "+ll+" "+lll);
                                }
                                
                                
                                String llll="";
                                if(t4!=null)
                                {
                                StringTokenizer st_4=new StringTokenizer(t4);
                                llll=st_4.nextToken("//");
                                //System.out.println(" "+l+" "+ll+" "+lll+" "+llll);
                                }
                                
                                
                                int t_1=Integer.parseInt(l);
                                int t_2=Integer.parseInt(ll);
                                int t_3=Integer.parseInt(lll);

                                Integer t_4=null;
                                if(t4!=null)
                                {
                                t_4=Integer.parseInt(llll);
                                }


                                faces.add(t_1);
                                faces.add(t_2);
                                faces.add(t_3);
                                
                                if(t4!=null)
                                {
                                faces.add(t_4);
                                } else {faces.add(null);}
                                count_faces++;
                                }
                         }       
                         //osobny fragment dla lamborghini
                        
                        if(lamborghini==false){
                                if(litera.equals("f"))
                                {
                                //System.out.println(linia);

                                String t1=st.nextToken(" ");
                                String t2=st.nextToken(" ");
                                String t3=st.nextToken(" ");





                                StringTokenizer st_1=new StringTokenizer(t1);
                                String l=st_1.nextToken("//");
                                String ll=st_1.nextToken("//");
                                if(crash_bandicoot==true) ll=st_1.nextToken("//");

                                StringTokenizer st_2=new StringTokenizer(t2);
                                String l2=st_2.nextToken("//");
                                String ll2=st_2.nextToken("//");
                                if(crash_bandicoot==true) ll2=st_2.nextToken("//");

                                StringTokenizer st_3=new StringTokenizer(t3);
                                String l3=st_3.nextToken("//");
                                String ll3=st_3.nextToken("//");
                                if(crash_bandicoot==true) ll3=st_3.nextToken("//");

                                String l4="";
                                String t4="";
                                String ll4="";

                                if(st.hasMoreTokens()){
                                t4=st.nextToken(" ");
                                StringTokenizer st_4=new StringTokenizer(t4);
                                l4=st_4.nextToken("//"); 
                                ll4=st_4.nextToken("//");
                                }
                        
                                //System.out.println(t1+" "+t2+" "+t3+" "+t4+" ");

                                //System.out.println(l+" "+l2+" "+l3+" "+l4);

                                //System.out.println(ll+" "+ll2+" "+ll3+" "+ll4);

                                int normal_ind=Integer.parseInt(ll);
                                //normals_index.add(normal_ind);

                                int t_1=Integer.parseInt(l);
                                int t_2=Integer.parseInt(l2);
                                int t_3=Integer.parseInt(l3);




                                faces.add(t_1);
                                faces.add(t_2);
                                faces.add(t_3);

                                    if(l4.equals("")!=true){
                                        int t_4=Integer.parseInt(l4);
                                        faces.add(t_4);
                                    }
                                count_faces++;
                        }
                                
                         
                                
                        }
                linia=bfr.readLine();
                }
                
                
                System.out.println("Vertices "+count_vertices);
                System.out.println("Faces "+count_faces);
                
                
                
                bfr.close();
                }catch(Exception exc){System.out.println("Exception "+exc);}
                
                //System.exit(1);
                
                for(Point3d p:vertices)
                {
                    p.rotateAxisY(0);
                    p.rotateAxisX(0);
                    //p.moveVectorOriginal(-200,20,0);
                    
                    if(lamborghini==true){p.moveVectorOriginal(-300,0,0);}
                    
                    //if(tomb_raider==true){p.moveVectorOriginal(0,400,300);}
                    //if(crash_bandicoot==true){p.moveVector(0,0,0);}
                }
                        
    this.add(b1);
    this.add(b2);
    this.add(b5);
    this.add(b3);
    this.add(b4);
    
    
    this.add(b6);
    this.add(b7);
    
    this.add(b8);
    this.add(b9);
    
    this.add(b10);
    this.add(b11);
    this.add(b12);
    
    b1.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        rotateLeft();
        }
    
    });
    
    b2.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        rotateRight();
        }
    
    });
    
    b3.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        rotateUp();
        }
    
    });
    
    b4.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        rotateDown();
        }
    
    });
    
    b5.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        play();
        }
    
    });
    
    
    b6.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
            scale=scale-100;
        }
    
    });
    
    b7.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
            scale=scale+100;
        }
    
    });
    
    b8.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
            wire_frame=true;
        }
    
    });
    
    b9.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
            wire_frame=false;
        }
    
    });
    
    b10.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        crash_bandicoot=true;
        lamborghini=false;
        tomb_raider=false;
        reload_application();
        }
    
    });
    
    b11.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        crash_bandicoot=false;
        lamborghini=false;
        tomb_raider=true;
        reload_application();    
        }
    
    });
    
    b12.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        crash_bandicoot=false;
        lamborghini=true;
        tomb_raider=false;
        reload_application();        
        }
    
    });
    
    }
    
    public void reload_application()
    {
        this.application_running=false;
        this.frame.dispose();
                
        R_3D r=new R_3D();
        
        r.panel = r;
        
        r.frame = new JFrame("Mateusz Pawlowski. 3D Software Renderer.");
        
        r.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
       
        
        r.thread=new Thread(r);
        r.thread.start();
        
        r.frame.getContentPane().add(r.panel);
        r.frame.setLocation(500, 300);
        r.frame.pack();
        r.frame.show();
        
        if(tomb_raider==true){ r.scale=r.scale+300;}
        r.rotateDown();
        r.rotateDown();
        r.rotateDown();
        if(play==true) r.play=true;
        
        
    }
    
    public void play()
    {
    this.play=true;
    }
    
    public void stop()
    {
    this.play=false;
    }
    
    public void rotateLeft()
    {
    stop();
    this.cube_angleY=this.cube_angleY+5;
    //if (this.cube_angleY>=360){this.cube_angleY=0;}
    //if (this.cube_angleY==0){this.cube_angleY=360-this.cube_angleY;}
    }
    
    public void rotateRight()
    {
    stop();
    this.cube_angleY=this.cube_angleY-5;
    }
    
    public void rotateUp()
    {
    stop();
    this.cube_angleX=this.cube_angleX-5;
    }
    
    public void rotateDown()
    {
    stop();
    this.cube_angleX=this.cube_angleX+5;
    }
    
    public void run()
    {
        
        while(application_running){
            try{
            Thread.sleep(10);
            }catch(InterruptedException exc){return;}
           
            //angle=this.cube_angle;
            //if (angle>=360){angle=0;} else angle=angle+1;
            if(this.play==true)
            {
            //cube_angleX++;
            cube_angleY++;
            }
            
            double a=angle; 
       
            for(Point3d p:tab)
            {
                
                p.rotateAxisY(cube_angleY);
                p.rotateAxisX(cube_angleX);
                p.calculate2dpoint();
            }

            pn1.rotateAxisY(cube_angleY);
            pn1.rotateAxisX(cube_angleX);
            
            pn2.rotateAxisY(cube_angleY);
            pn2.rotateAxisX(cube_angleX);
            
            pn3.rotateAxisY(cube_angleY);
            pn3.rotateAxisX(cube_angleX);
        
            pn4.rotateAxisY(cube_angleY);
            pn4.rotateAxisX(cube_angleX);
    
            pn5.rotateAxisY(cube_angleY);
            pn5.rotateAxisX(cube_angleX);
            
            pn6.rotateAxisY(cube_angleY);
            pn6.rotateAxisX(cube_angleX);
    
            
            for(Point3d p:vertices)
            {
            p.rotateAxisY(cube_angleY);
            p.rotateAxisX(cube_angleX);
            
            if(lamborghini==true){p.moveVector(50,50,0+scale);}
            if(crash_bandicoot==true){p.moveVector(350,800,2000+scale);}
            if(tomb_raider==true){p.moveVector(100,350,450+scale);}
            
            p.calculate2dpoint();
            }
            
            this.repaint();
        }
        
    }
      public void paintComponent(Graphics g){
        
	super.paintComponent(g);
     
        g.setColor(Color.white);
        g.fillRect(0, 0, 640, 480);
        g.setColor(Color.black);
        
        
        this.g=g;
        
        
        //draw demo
        if(draw_demo==true){
        /*
        line(p1.x2d, p1.y2d, p2.x2d, p2.y2d);
        line(p1.x2d, p1.y2d, p3.x2d, p3.y2d);
        line(p3.x2d, p3.y2d, p4.x2d, p4.y2d);
        line(p2.x2d, p2.y2d, p4.x2d, p4.y2d);
        
        line(p5.x2d, p5.y2d, p6.x2d, p6.y2d);
        line(p5.x2d, p5.y2d, p7.x2d, p7.y2d);
        line(p7.x2d, p7.y2d, p8.x2d, p8.y2d);
        line(p6.x2d, p6.y2d, p8.x2d, p8.y2d);
        
        line(p1.x2d, p1.y2d, p5.x2d, p5.y2d);
        line(p2.x2d, p2.y2d, p6.x2d, p6.y2d);
        line(p3.x2d, p3.y2d, p7.x2d, p7.y2d);
        line(p4.x2d, p4.y2d, p8.x2d, p8.y2d);
        */
        
        Vect vo=new Vect(0,0,-1);
        
        //Vect v1=new Vect(p1.xr2-p2.xr2,p1.yr2-p2.yr2,p1.zr2-p2.zr2);
        //Vect v2=new Vect(p2.xr2-p4.xr2,p2.yr2-p4.yr2,p2.zr2-p4.zr2);
        
        //Vect v2n=Vect.getNormal(v1, v2);
       
        double k=0.8;
        
        Vect v1n=new Vect(pn1.xr2,pn1.yr2,pn1.zr2);
        Vect v2n=new Vect(pn2.xr2,pn2.yr2,pn2.zr2);
        Vect v3n=new Vect(pn3.xr2,pn3.yr2,pn3.zr2);
        Vect v4n=new Vect(pn4.xr2,pn4.yr2,pn4.zr2);
        Vect v5n=new Vect(pn5.xr2,pn5.yr2,pn5.zr2);
        Vect v6n=new Vect(pn6.xr2,pn6.yr2,pn6.zr2);
        
        double visibleWall=Vect.getDotProduct(v1n, vo);
        double visibleWall2=Vect.getDotProduct(v2n, vo);
        double visibleWall3=Vect.getDotProduct(v3n, vo);
        double visibleWall4=Vect.getDotProduct(v4n, vo);
        double visibleWall5=Vect.getDotProduct(v5n, vo);
        double visibleWall6=Vect.getDotProduct(v6n, vo);
        
        Polygon wall=new Polygon();
        wall.addPoint(p1.x2d, p1.y2d);
        wall.addPoint(p2.x2d, p2.y2d);
        wall.addPoint(p4.x2d, p4.y2d);
        wall.addPoint(p3.x2d, p3.y2d);
        wall.translate(60,-20);
        
        //g.setColor(new Color(0,200,0));
        //g.fillPolygon(wall);
        
        g.setColor(new Color(0,150+(int)(k*8*visibleWall),0));
        if(visibleWall>0){g.fillPolygon(wall);}
        
        
               
        Polygon wall2=new Polygon();
        wall2.addPoint(p5.x2d, p5.y2d);
        wall2.addPoint(p6.x2d, p6.y2d);
        wall2.addPoint(p8.x2d, p8.y2d);
        wall2.addPoint(p7.x2d, p7.y2d);
        wall2.translate(60,-20);
        g.setColor(new Color(0,150+(int)(k*8*visibleWall2),0));
        if(visibleWall2>0){g.fillPolygon(wall2);}
        
       
        Polygon wall3=new Polygon();
        wall3.addPoint(p1.x2d, p1.y2d);
        wall3.addPoint(p5.x2d, p5.y2d);
        wall3.addPoint(p6.x2d, p6.y2d);
        wall3.addPoint(p2.x2d, p2.y2d);
        wall3.translate(60,-20);
        g.setColor(new Color(0,150+(int)(k*8*visibleWall3),0));
        if(visibleWall3>0){g.fillPolygon(wall3);}
        
        
        Polygon wall4=new Polygon();
        wall4.addPoint(p3.x2d, p3.y2d);
        wall4.addPoint(p7.x2d, p7.y2d);
        wall4.addPoint(p8.x2d, p8.y2d);
        wall4.addPoint(p4.x2d, p4.y2d);
        wall4.translate(60,-20);
        g.setColor(new Color(0,150+(int)(k*8*visibleWall4),0));
        if(visibleWall4>0){g.fillPolygon(wall4);}
        
        Polygon wall5=new Polygon();
        wall5.addPoint(p2.x2d, p2.y2d);
        wall5.addPoint(p6.x2d, p6.y2d);
        wall5.addPoint(p8.x2d, p8.y2d);
        wall5.addPoint(p4.x2d, p4.y2d);
        wall5.translate(60,-20);
        g.setColor(new Color(0,150+(int)(k*8*visibleWall5),0));
        if(visibleWall5>0){g.fillPolygon(wall5);}
        
        Polygon wall6=new Polygon();
        wall6.addPoint(p1.x2d, p1.y2d);
        wall6.addPoint(p5.x2d, p5.y2d);
        wall6.addPoint(p7.x2d, p7.y2d);
        wall6.addPoint(p3.x2d, p3.y2d);
        wall6.translate(60,-20);
        g.setColor(new Color(0,150+(int)(k*8*visibleWall6),0));
        if(visibleWall6>0){g.fillPolygon(wall6);}
        
        //draw demo end
        }
        
        g.setColor(Color.black);
        
        
        for(Point3d p:vertices)
        {
            p.calculate2dpoint();
            g.drawLine(p.x2d,p.y2d, p.x2d,p.y2d);
        }
        
        ArrayList<Triangle> triangles=new ArrayList<Triangle>();
         
        if(lamborghini==true){
            
                for(int i=0;i<14784;i++)
                {
                    int w1=faces.get(i);
                    
                    
                    i++;
                    int w2=faces.get(i);
                    i++;
                    int w3=faces.get(i);
                    i++;
                    
                    Integer w4=null;
                    
                    
                    if(faces.get(i)!=null)
                    {
                    
                    w4=faces.get(i);
                    
                    }
                    
                    Point3d p1=vertices.get(w1-1);
                    Point3d p2=vertices.get(w2-1);
                    Point3d p3=vertices.get(w3-1);
                    
                    Point3d p4=null;
                    
                    if(w4!=null)
                    {
                       
                    p4=vertices.get(w4-1);
                    }
                    
                    if(p4==null)
                    {
                    triangles.add(new Triangle(p1,p2,p3));
                    }
                    else
                    {
                    triangles.add(new Triangle(p1,p2,p3,p4));
                    }
                   
                }
                
                try{
                Collections.sort(triangles);
                }catch(Exception exc){};
                
                
                for(Triangle t:triangles)
                {
                    Polygon poly=new Polygon();
                    poly.addPoint(t.v1.x2d,t.v1.y2d);
                    poly.addPoint(t.v2.x2d,t.v2.y2d);
                    poly.addPoint(t.v3.x2d,t.v3.y2d);
                    
                    
                    Polygon poly2=new Polygon();
                   
                    
                    if(t.v4!=null)
                    {
                    poly.addPoint(t.v4.x2d,t.v4.y2d);
                         
                    poly2.addPoint(t.v1.x2d,t.v1.y2d);
                    poly2.addPoint(t.v3.x2d,t.v3.y2d);
                    poly2.addPoint(t.v4.x2d,t.v4.y2d);
                    }
                     
                    int color=250;
                    
                    
                    //color=100-(int)(33*t.v1.zr2);
                    if(color>255) color=255;
                    if(color<0) color=0;
                    
                    g.setColor(new Color(color,color,color));
                    
                    if(wire_frame==false)
                    {
                    g.fillPolygon(poly);
                    
                    //g.fillPolygon(poly2);
                    //g.fillPolygon(poly3);
                    //g.fillPolygon(poly4);
                    }
                    
                    g.setColor(new Color(0,0,0));
                    g.drawLine(t.v1.x2d,t.v1.y2d, t.v2.x2d,t.v2.y2d);
                    g.drawLine(t.v2.x2d,t.v2.y2d, t.v3.x2d,t.v3.y2d);
                    
                    if(t.v4==null)
                    {
                    g.drawLine(t.v3.x2d,t.v3.y2d, t.v1.x2d,t.v1.y2d);
                    }
                    
                    if(t.v4!=null)
                    {
                    g.drawLine(t.v3.x2d,t.v3.y2d, t.v4.x2d,t.v4.y2d);
                    g.drawLine(t.v4.x2d,t.v4.y2d, t.v1.x2d,t.v1.y2d);
                    }
                     
                }
        }
        
        
         if(tomb_raider==true){
                for(int i=0;i<21414;i++)
                {
                    int w1=faces.get(i);
                    i++;
                    int w2=faces.get(i);
                    i++;
                    int w3=faces.get(i);
                    //i++;
                    //int w4=faces.get(i);

                    Point3d p1=vertices.get(w1-1);
                    Point3d p2=vertices.get(w2-1);
                    Point3d p3=vertices.get(w3-1);
                    //Point3d p4=vertices.get(w4-1);

                    triangles.add(new Triangle(p1,p2,p3));
                     
                    Polygon poly=new Polygon();
                    poly.addPoint(p1.x2d,p1.y2d);
                    poly.addPoint(p2.x2d,p2.y2d);
                    poly.addPoint(p3.x2d,p3.y2d);
                }
                
                try{
                Collections.sort(triangles);
                }catch(Exception exc){};
                
                for(Triangle t:triangles)
                {
                    
                    
                    
                    
                    
                    Polygon poly=new Polygon();
                    poly.addPoint(t.v1.x2d,t.v1.y2d);
                    poly.addPoint(t.v2.x2d,t.v2.y2d);
                    poly.addPoint(t.v3.x2d,t.v3.y2d);
                    //int color=255-(int)(0.01f*t.v1.zr2);
                    int color=250;
                    g.setColor(new Color(color,color,color));
                   
                    if(wire_frame==false)
                    {
                    g.fillPolygon(poly);
                    }
                    
                    g.setColor(new Color(0,0,0));
                    g.drawLine(t.v1.x2d,t.v1.y2d, t.v2.x2d,t.v2.y2d);
                    g.drawLine(t.v2.x2d,t.v2.y2d, t.v3.x2d,t.v3.y2d);
                    g.drawLine(t.v3.x2d,t.v3.y2d, t.v1.x2d,t.v1.y2d);
                }
        }
         
        
         
         if(crash_bandicoot==true){
             int q=0;
                for(int i=0;i<2196;i++)
                {
                   
                    q++;
                    
                    int w1=faces.get(i);
                    i++;
                    int w2=faces.get(i);
                    i++;
                    int w3=faces.get(i);
                    //i++;
                    //int w4=faces.get(i);

                    Point3d p1=vertices.get(w1-1);
                    Point3d p2=vertices.get(w2-1);
                    Point3d p3=vertices.get(w3-1);
                    //Point3d p4=vertices.get(w4-1);
                    triangles.add(new Triangle(p1,p2,p3));
                    
                    
                }
                
                try{
                Collections.sort(triangles);
                }catch(Exception exc){};
                
                for(Triangle t:triangles)
                {
                    Polygon poly=new Polygon();
                    poly.addPoint(t.v1.x2d,t.v1.y2d);
                    poly.addPoint(t.v2.x2d,t.v2.y2d);
                    poly.addPoint(t.v3.x2d,t.v3.y2d);
                    int color=255-(int)(0.01f*t.v1.zr2);
                    color=250;
                    if(color>=255) color=255;
                    if(color<=0) color=0;
                    
                    g.setColor(new Color(color,color,color));

                    if(wire_frame==false)
                    {
                    g.fillPolygon(poly);
                    }

                    g.setColor(new Color(0,0,0));
                    g.drawLine(t.v1.x2d,t.v1.y2d, t.v2.x2d,t.v2.y2d);
                    g.drawLine(t.v2.x2d,t.v2.y2d, t.v3.x2d,t.v3.y2d);
                    g.drawLine(t.v3.x2d,t.v3.y2d, t.v1.x2d,t.v1.y2d);
                }
        }
         
        g.setColor(Color.black);
        g.setFont(new Font("System", Font.BOLD, 10));
        g.drawString("Mateusz Pawlowski. 3D Software Renderer. 2023.", 190, 450);
    }

    public void line(int x,int y,int x2,int y2)
    {
    g.drawLine(x+60, y-20,x2+60,y2-20);
    }
    
    public Dimension getPreferredSize(){
        return new Dimension(640, 480);
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        
        R_3D rds=new R_3D();
        
        
        rds.panel=rds;
        
        rds.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
       
        
        rds.thread=new Thread(rds);
        rds.thread.start();
        
        rds.frame.getContentPane().add(rds.panel);
        rds.frame.setLocation(500, 300);
        rds.frame.pack();
        rds.frame.show();
        
        rds.rotateDown();
        rds.rotateDown();
        rds.rotateDown();
        rds.play();
        
    }
    
}
